package com.altim.qa.tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.altim.qa.listeners.ReportListener;
import com.altim.qa.pages.BookingPage;
import com.altim.qa.pages.SearchPage;
import com.altim.qa.pages.SearchResultPage;
import com.altim.qa.util.TestProperties;
import com.aventstack.extentreports.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Listeners(ReportListener.class)
public class SearchTest extends BaseTest {
    private WebDriver driver;
    Properties props;

    @BeforeTest
    public void setParameters() {
    	TestProperties.loadAllPropertie();
    }
    
	@Test(priority=0)
	public void parentTest() {	
		test = extent.createTest("Validate the prices");
		test.assignCategory("Functional Test");
		childTest = test.createNode("create to keep 'FlightSearch()' as a child test.");
	}


    @Test
    public void FlightSearch() throws InterruptedException {
    	
    	childTest = test.createNode("FlightSearch ");
		test.assignCategory("Functional Test | FlightSearch");
		
        SearchPage flightSearchPage = new SearchPage(driver);
        flightSearchPage.getMMTPage(props.getProperty("url"));
        flightSearchPage.selectFromCity(props.getProperty("fromcity1"));
        flightSearchPage.selectToCity(props.getProperty("tocity1"));
        flightSearchPage.pressEsc();
        flightSearchPage.clickSearch();
        SearchResultPage flightSearchResultPage = new SearchResultPage(driver);
        flightSearchResultPage.printHoldOnMessage();
        flightSearchResultPage.handleLockPriceWindow();

        List<String> AirLineNames = flightSearchResultPage.getAirlineNames();
        test.log(Status.INFO, "Number of Flights Showing : "+ String.valueOf(AirLineNames.size()));

        //Log all the flight names in ascending order by the departure time.
        flightSearchResultPage.selectOtherSort("Early Departure");
        flightSearchResultPage.handleLockPriceWindow();
        List<String> AirLineNamesAftSort = flightSearchResultPage.getAirlineNames();
        //System.out.println(Arrays.toString(AirLineNamesAftSort.toArray()));
        test.log(Status.INFO, "Airlines displaying in ascending order by the departure time  : "+ String.valueOf(AirLineNamesAftSort));
        //From “Popular Filters”, filter the airlines by “Indigo” and log all the Flight number, Departure
        //time, Arrival time, and Price/Adult respectively
        flightSearchResultPage.selectPopularFilter(props.getProperty("popular"));
        List<String> flightNames = flightSearchResultPage.getAirlineNames();

        if (flightNames.stream().distinct().count() == 1) {
            List<String> flightNumbers = flightSearchResultPage.getAllFlightNumbers();
            List<String> flightDep = flightSearchResultPage.getFlightDepartureTime();
            List<String> flightArr = flightSearchResultPage.getFlightArrivalTime();
            List<String> flightPrices = flightSearchResultPage.getAllFlightPrices("oneway");

            if (flightNumbers.size() == flightDep.size()
                    && flightDep.size() == flightArr.size()
                    && flightArr.size() == flightPrices.size()) {
                ArrayList<String> Flightdetails = new ArrayList<>();
                for (int i = 0; i < flightNumbers.size(); i++) {
                    Flightdetails.add(flightNumbers.get(i) + " " + flightDep.get(i) + " " + flightArr.get(i) + " " + flightPrices.get(i));
                    //System.out.println(flightNumbers.get(i) +" "+flightDep.get(i)+" "+flightArr.get(i)+" "+flightPrices.get(i));
                }
                test.log(Status.INFO, "logging all the Flight number, Departure time Arrival time and Price"+ String.valueOf(Flightdetails));
                test.log(Status.PASS, "Flight number, Departure time Arrival time and Price");
            } else {
                Assert.fail("There is miss match in size of number of flights, price and timings");
                test.log(Status.FAIL, "There is miss match in size of number of flights, price and timings");
            }
        } else {
            System.out.println("****Filter functionality is not functioning correctly******");
            test.log(Status.FAIL, "Filter functionality is not functioning correctly");
        }

        //Filter the “Non-Stop” and the cheapest Indigo flight. Log its Flight number and its fare
        flightSearchResultPage.SelectCheapestPrice();
        flightSearchResultPage.getFirstFlightDetails();
        String[] flightNo = flightSearchResultPage.getFirstFlightDetails();
        System.out.println("Cheapest flight number and price are : " + flightNo[0] + "::" + flightNo[1]);
        test.log(Status.INFO, "Cheapest flight number and price are"+ flightNo[0] + "::" + flightNo[1]);

        //Click on “View Prices” of the cheapest Indigo flight as in the previous point.
        flightSearchResultPage.selectViewPrice();
        BookingPage completebooking = flightSearchResultPage.bookSaverOption(flightNo[1]);
        completebooking.handlePriceRisePopup();

        //log the “Fare Summary” which includes “Base Fare”, “Tax and Surcharges”, and “Total Amount”.
        //completebooking.isAt();
        String basePrice = completebooking.getBasePrice();
        String taxAndSurchargePrice = completebooking.getTaxesAndSurchargesPrice();
        String TotalAmount = completebooking.getTotalAmount();
        completebooking.closeWindow();
        System.out.println("total amt : " + TotalAmount);
        test.log(Status.INFO, "base price, tax and surcharge price and total amount is : "+ basePrice + " , " + taxAndSurchargePrice + " , " + TotalAmount);


    }

}
