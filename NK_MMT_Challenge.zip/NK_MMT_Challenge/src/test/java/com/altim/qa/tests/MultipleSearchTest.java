package com.altim.qa.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.altim.qa.pages.SearchPage;
import com.altim.qa.pages.SearchResultPage;
import com.altim.qa.util.TestProperties;
import com.aventstack.extentreports.Status;

import java.util.List;
import java.util.Properties;

public class MultipleSearchTest extends BaseTest {

	private WebDriver driver;
	Properties props;

    @BeforeTest
    public void setParameters() {
    	TestProperties.loadAllPropertie();
    }
    
	@Test(priority=0)
	public void parentTest() {	
		test = extent.createTest("Validate the multiple search");
		test.assignCategory("Functional Test");
		childTest = test.createNode("create to keep 'multiWaySearch' as a child test.");
	}


    @Test
    public void multiWaySearch() throws InterruptedException {
    	
    	childTest = test.createNode("multiWaySearch ");
		test.assignCategory("Functional Test | multiWaySearch");

    	SearchPage flightsSearchPage = new SearchPage(driver);
        flightsSearchPage.getMMTPage(props.getProperty("url"));
        flightsSearchPage.listAllSuggestedCities(props.getProperty("fromcity1").substring(0, 2));
        flightsSearchPage.pressEsc();
        flightsSearchPage.selectTripType(props.getProperty("triptype"));
        flightsSearchPage.selectFromCity1(props.getProperty("fromcity1"));
        flightsSearchPage.selectToCity1(props.getProperty("tocity1"));
        flightsSearchPage.selectDate(0);
        flightsSearchPage.selectFromCity2(props.getProperty("tocity1"));
        flightsSearchPage.selectToCity2(props.getProperty("tocity1"));
        flightsSearchPage.selectDate(2);
        flightsSearchPage.clickSearch();
        SearchResultPage flightSearchResultPage = new SearchResultPage(driver);
        //flightSearchResultPage.printHoldOnMessage();
        //flightSearchResultPage.isAt();
        flightSearchResultPage.dragPriceSlider("min");
        Thread.sleep(1000);
        flightSearchResultPage.dragPriceSlider("max");
        //log all the flight numbers and prices in ascending order of departure time
        flightSearchResultPage.handleLockPriceWindow();
        List<String> flightNames = flightSearchResultPage.getAirlineNames();
        test.log(Status.INFO, "Number of Flights Showing : "+flightNames);
        List<String> flightPrices = flightSearchResultPage.getAllFlightPrices("mulitiCityTrip");
        test.log(Status.INFO, "Price of Flights Showing : "+flightPrices);
        if (flightNames.size() == flightPrices.size()) {
            System.out.println("****log all the Flight number and Price******");
            for (int i = 0; i < flightNames.size(); i++) {
                System.out.println(flightNames.get(i) + ":" + flightPrices.get(i));
            }
            test.log(Status.PASS, "all the Flight number and Price");
        } else {
            System.out.println("****Incorrect Filter, miss match in no of flights and no of prices displaying ******");
            test.log(Status.FAIL, "Incorrect Filter, miss match in no of flights and no of prices displaying");
        }
    }
}
