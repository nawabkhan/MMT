package com.altim.qa.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SearchPage extends BasePage {
    @FindBy(id = "fromCity")
    private WebElement selectFromCityInput;
    @FindBy(id = "toCity")
    private WebElement selectToCityInput;
    @FindBy(css = ".primaryBtn.font24.latoBold.widgetSearchBtn")
    private WebElement searchButton;
    @FindBy(css = "#react-autowhatever-1 > div > ul > li")
    private List<WebElement> popularCitiesLst;
    @FindBy(className = ".fswTabs.latoRegular.darkGreyText")
    private List<WebElement> tripTypeRadioButton;
    @FindBy(id = "fromAnotherCity0")
    private WebElement fromCity1;
    @FindBy(id = "toAnotherCity0")
    private WebElement toCity1;
    @FindBy(id = "fromAnotherCity1")
    private WebElement fromCity2;
    @FindBy(id = "toAnotherCity1")
    private WebElement toCity2;
    @FindBy(css = "div[class='DayPicker-Day'][aria-disabled='false']")
    private List<WebElement> calendarDates;
    @FindBy(css = ".chNavIcon.appendBottom2.chSprite.chForex")
    private WebElement forexCardImage;


    public SearchPage(WebDriver driver) {
        super(driver);
    }

    public void selectCityFromPopularCitiesList(String city) {
        boolean f = false;
        for (WebElement e : popularCitiesLst) {
            if (e.getText().toLowerCase().contains(city.toLowerCase())) {
                //e.click();
                int attempts = 0;
                while (attempts < 4) {
                    try {
                        e.click();
                        break;
                    } catch (StaleElementReferenceException | NoSuchElementException ex) {
                        System.out.println("Attempt " + (attempts + 1) + ": Retrying finding element...");
                    }
                    attempts++;
                }
                f = true;
                break;
            }
        }
        if (!f)
            Assert.fail("unable to find given city : " + city);
    }

    public void selectFromCity(String FromCity) {
    //    wait.until(ExpectedConditions.visibilityOf(this.selectFromCityInput));
        this.selectFromCityInput.sendKeys(FromCity);
        selectCityFromPopularCitiesList(FromCity);
    }

    public void listAllSuggestedCities(String FromCity) {
        this.selectFromCityInput.sendKeys(FromCity);
        List<String> suggestedCities = this.popularCitiesLst.stream().map(WebElement::getText).collect(Collectors.toList());
        System.out.println("All suggested cities list :: "+ Arrays.toString(suggestedCities.toArray()));
    }

    public void selectToCity(String ToCity) {
        this.selectToCityInput.sendKeys(ToCity);
        selectCityFromPopularCitiesList(ToCity);
    }

    public void pressEsc() {
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE).perform();
    }

    public void clickSearch() {
        this.searchButton.click();
    }

    public void getMMTPage(String url) {
        driver.get(url);
    }



    public void selectTripType(String tripType) {
        driver.findElement(By.cssSelector("li[data-cy='" + tripType + "']")).click();
    }

    public void selectDate(int days) {
        // Calculate the desired date (2 days after today)
        if (days == 0) {
            pressEsc();
            return;
        }
        LocalDate currentDate = LocalDate.now();
        LocalDate desiredDate = currentDate.plusDays(days);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d"); // Format to match day of month
        String dayString = desiredDate.format(formatter);

        for (WebElement e : this.calendarDates) {
            if (e.getText().equals(dayString)) {
                e.click();
                break;
            }
        }

    }

    public void selectFromCity1(String city) {
        this.fromCity1.sendKeys(city);
        selectCityFromPopularCitiesList(city);
    }

    public void selectToCity1(String city) {
        this.toCity1.sendKeys(city);
        selectCityFromPopularCitiesList(city);
    }

    public void selectFromCity2(String city) {
        this.fromCity2.sendKeys(city);
        selectCityFromPopularCitiesList(city);
    }

    public void selectToCity2(String city) {
        this.toCity2.sendKeys(city);
        selectCityFromPopularCitiesList(city);
    }
    
    public CurrencyPage selectForexCard() {
        this.forexCardImage.click();
        return new CurrencyPage(driver);
    }


}
