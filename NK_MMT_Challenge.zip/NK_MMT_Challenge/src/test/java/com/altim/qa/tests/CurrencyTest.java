package com.altim.qa.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.altim.qa.pages.CurrencyPage;
import com.altim.qa.pages.SearchPage;
import com.altim.qa.util.TestProperties;
import com.aventstack.extentreports.Status;

import java.util.Properties;

public class CurrencyTest extends BaseTest {

    private WebDriver driver;
    Properties props;

    @BeforeTest
    public void setParameters() {
    	TestProperties.loadAllPropertie();

    }
    
	@Test(priority=0)
	public void parentTest() {	
		test = extent.createTest("Validate the currency");
		test.assignCategory("Functional Test");
		childTest = test.createNode("create to keep 'currencyValidations()' as a child test.");
	}

    @Test
    public void currencyValidations() throws InterruptedException {
    	
    	childTest = test.createNode("currencyValidations ");
		test.assignCategory("Functional Test | currencyValidations");

        try {
			SearchPage flightsSearchPage = new SearchPage(driver);
			flightsSearchPage.getMMTPage(props.getProperty("url"));
			CurrencyPage forexPage = flightsSearchPage.selectForexCard();
			forexPage.printExchangeRate(new String[]{"EUR", "USD", "NZD"});
			forexPage.clickMultiCurrencyCardButton();
			String def = forexPage.selectAndPrintFaqQuestion("What is a Multicurrency Card?");
			test.log(Status.INFO, "What is a Multicurrency Card : "+ def);
			forexPage.reverseAlternateWords(def);
			test.log(Status.PASS, "show valid currency");
		} catch (Exception e) {
			test.log(Status.FAIL, "show valid currency");
		}

    }
}
